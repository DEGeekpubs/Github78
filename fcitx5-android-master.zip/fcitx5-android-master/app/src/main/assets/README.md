# Assets

The entire assets will be synced to application's data directory at runtime. `descriptor.json`
is generated at build time, saving file SHA256 for syncing.